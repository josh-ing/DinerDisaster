Welcome.... to Diner Disaster!
**parody of diner dash

How to play:
Arrow keys to move.
Select to restart.

The customer is hungry for our world famous rotisserie chicken! But at the same time, there's a food fight in the dining hall and tomatos are flying about! Try to serve
the food to the customer while avoiding the tomatos!
If you deliver the food to 5 customers, you win the game. One hit, and you're out :(


by Joshua Ng
CS 2110 