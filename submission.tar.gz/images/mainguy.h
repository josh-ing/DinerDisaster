/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=40x37 mainguy mainguy.png 
 * Time-stamp: Friday 11/06/2020, 22:45:42
 * 
 * Image Information
 * -----------------
 * mainguy.png 40@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MAINGUY_H
#define MAINGUY_H

extern const unsigned short mainguy[1480];
#define MAINGUY_SIZE 2960
#define MAINGUY_LENGTH 1480
#define MAINGUY_WIDTH 40
#define MAINGUY_HEIGHT 37

#endif

