/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=35x37 customerdefault customerdefault.png 
 * Time-stamp: Friday 11/06/2020, 22:46:43
 * 
 * Image Information
 * -----------------
 * customerdefault.png 35@37
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef CUSTOMERDEFAULT_H
#define CUSTOMERDEFAULT_H

extern const unsigned short customerdefault[1295];
#define CUSTOMERDEFAULT_SIZE 2590
#define CUSTOMERDEFAULT_LENGTH 1295
#define CUSTOMERDEFAULT_WIDTH 35
#define CUSTOMERDEFAULT_HEIGHT 37

#endif

