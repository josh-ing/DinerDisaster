/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=30x30 food food.png 
 * Time-stamp: Friday 11/06/2020, 22:47:32
 * 
 * Image Information
 * -----------------
 * food.png 30@30
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef FOOD_H
#define FOOD_H

extern const unsigned short food[900];
#define FOOD_SIZE 1800
#define FOOD_LENGTH 900
#define FOOD_WIDTH 30
#define FOOD_HEIGHT 30

#endif

