/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=15x15 projectile projectile.png 
 * Time-stamp: Tuesday 11/10/2020, 02:43:15
 * 
 * Image Information
 * -----------------
 * projectile.png 15@15
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef PROJECTILE_H
#define PROJECTILE_H

extern const unsigned short projectile[225];
#define PROJECTILE_SIZE 450
#define PROJECTILE_LENGTH 225
#define PROJECTILE_WIDTH 15
#define PROJECTILE_HEIGHT 15

#endif

