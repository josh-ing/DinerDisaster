/*
 * Exported with nin10kit v1.7
 * Invocation command was nin10kit --mode=3 --resize=35x35 mainfood mainfood.png 
 * Time-stamp: Tuesday 11/10/2020, 02:42:34
 * 
 * Image Information
 * -----------------
 * mainfood.png 35@35
 * 
 * All bug reports / feature requests are to be filed here https://github.com/TricksterGuy/nin10kit/issues
 */

#ifndef MAINFOOD_H
#define MAINFOOD_H

extern const unsigned short mainfood[1225];
#define MAINFOOD_SIZE 2450
#define MAINFOOD_LENGTH 1225
#define MAINFOOD_WIDTH 35
#define MAINFOOD_HEIGHT 35

#endif

